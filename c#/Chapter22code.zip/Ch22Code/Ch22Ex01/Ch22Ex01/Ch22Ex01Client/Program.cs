﻿using Ch22Ex01Client.ServiceReference1;
using static System.Console;

namespace Ch22Ex01Client
{
  class Program
  {
    static void Main(string[] args)
    {
      Title = "Ch22Ex01Client";
      string numericInput = null;
      int intParam;
      do
      {
        WriteLine(
           "Enter an integer and press enter to call the WCF service.");
        numericInput = ReadLine();
      }
      while (!int.TryParse(numericInput, out intParam));
      Service1Client client = new Service1Client();
      WriteLine(client.GetData(intParam));
      WriteLine("Press an key to exit.");
      ReadKey();
    }
  }
}
