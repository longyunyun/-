﻿using System;
using System.Collections.Generic;
using System.Web;

public enum Suit
{
      Club,
      Diamond,
      Heart,
      Spade,
}
