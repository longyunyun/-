﻿using System;
using System.Collections.Generic;
using System.Web;

public enum Rank
{
      Ace = 1,
      Deuce,
      Three,
      Four,
      Five,
      Six,
      Seven,
      Eight,
      Nine,
      Ten,
      Jack,
      Queen,
      King,
 }
